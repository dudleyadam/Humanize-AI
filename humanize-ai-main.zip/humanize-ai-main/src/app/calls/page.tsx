
import CallLogs from "@/components/logs/CallLogs";

export default function CallLogsPage() {
  return (
    <CallLogs />
  );
} 