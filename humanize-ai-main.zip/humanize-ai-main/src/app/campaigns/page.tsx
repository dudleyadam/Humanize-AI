import React from 'react'
import MainCampaign from '@/components/campaign/MainCampaign'


const CampaignsPage = () => {
  return (
    <div>
      <MainCampaign />
    </div>
  )
}
export default CampaignsPage
