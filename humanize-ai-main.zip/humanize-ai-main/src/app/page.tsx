import { MainOverview } from "@/components/overview/MainOverview";



export default function DashboardPage() {
 
  return (
   
      <MainOverview />
 
  );
}
