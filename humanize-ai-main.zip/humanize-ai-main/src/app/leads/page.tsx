import MainLeads from '@/components/Leads/MainLeads'
import React from 'react'

const page = () => {
  return (
    <div>
      <MainLeads />
    </div>
  )
}

export default page